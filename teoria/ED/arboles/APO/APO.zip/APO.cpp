#include <cassert>
#include <iostream>
#include "APO.hpp"

using namespace std;

template <class Tbase>
APO<Tbase>::APO(){
  vec = new Tbase;
  nelementos = 0;
  reservados = 1;
}

template <class Tbase>
APO<Tbase>::APO(int tam){
  assert(tam>0);
  vec = new Tbase[tam];
  nelementos = 0;
  reservados = tam;
}

template <class Tbase>
APO<Tbase>::APO(const APO<Tbase>& a){

  nelementos = a.nelementos;
  reservados = (nelementos==0) ? 1 : nelementos;
  vec = new Tbase[reservados];
  for(int i=0; i<nelementos; i++)
    vec[i] = a.vec[i];
}

template <class Tbase>
APO<Tbase>::~APO(){
  delete[] vec;
}

template <class Tbase>
APO<Tbase>& APO<Tbase>::operator=(const APO<Tbase> &a){
  if (this != &a){
    delete[] vec;
    reservados = nelementos = a.nelementos;
    vec = new Tbase[nelementos];
    for(int i=0; i<nelementos; i++)
      vec[i] = a.vec[i];
  }
  return *this;
}

template <class Tbase>
const Tbase& APO<Tbase>::minimo() const{
  assert(nelementos>0);
  return vec[0];
}

template <class Tbase>
void APO<Tbase>::insertar(const Tbase &e){
  int pos;
  if (nelementos == reservados)
    expandir(2*reservados);
  nelementos++;
  pos = nelementos-1;
  vec[pos] = e;
  //Mientras el elemento sea menor que su padre
  //lo promocionamos, intercambiándolo con él
  while((pos>0) && (vec[pos]<vec[(pos-1)/2])){
    intercambiar(vec[pos], vec[(pos-1)/2]);
    pos = (pos-1)/2;
  }
}

template <class Tbase>
void APO<Tbase>::borrar_minimo(){
  int pos, pos_min, ultimo;
  bool terminar;
  
  assert(nelementos>0);
  //Colocamos la última hoja en la raíz
  vec[0] = vec[nelementos-1];
  nelementos--;
  if(nelementos>1){
    ultimo = nelementos-1;
    pos = 0;
    terminar = false;
    //Mientras queden niveles por recorrer (bajada)
    while(pos<=(ultimo-1)/2 && !terminar){
      //Si no hay hijo derecha
      if(ultimo == 2*pos+1)
        //el minimo de los hijos es el izquierdo
        pos_min = 2*pos+1;
      //Si tiene los dos hijos, los comparamos
      //para seleccionar el mínimo
      else if (vec[2*pos+1] < vec[2*pos+2])
        pos_min = 2*pos+1;
      else
        pos_min = 2*pos+2;
      //Si es mayor que el mínimo de los hijos
      //promocionamos ese hijo intercambiándolos
      if(vec[pos_min]<vec[pos]){
        intercambiar(vec[pos], vec[pos_min]);
        pos = pos_min;
      }
      else //Si no, hemos terminado
        terminar = true;
    }
  }
}

template <class Tbase>
void APO<Tbase>::clear(){
  nelementos = 0;
}

template <class Tbase>
int APO<Tbase>::size() const{
  return nelementos;
}

template <class Tbase>
bool APO<Tbase>::empty() const{
  return (nelementos == 0);
}

//Funciones privadas


template <class Tbase>
void APO<Tbase>::expandir(int nelem){
  Tbase* aux;
  assert(nelem>reservados);
  
  aux = new Tbase[nelem];
  for(int i=0; i<nelementos; i++)
    aux[i] = vec[i];
  delete[] vec;
  vec = aux;
  reservados = nelem;
}

//Función externa

template <class Tbase>
void intercambiar(Tbase& a, Tbase& b){
  Tbase aux = a;
  a = b;
  b = aux;
}

