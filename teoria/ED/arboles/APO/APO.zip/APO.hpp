#ifndef APO_hpp
#define APO_hpp

/**
 @brief TDA APO
 
 Definición:
 
 Una instancia, a, del TDA APO sobre un dominio Tbase es un árbol binario con
 etiquetas en Tbase y un orden parcial que consiste en que la etiqueta de un
 nodo es menor o igual que la de sus descendientes. Para poder gestionarlo,
 el tipo Tbase debe tener definida la operación <
 */

template <class Tbase>
class APO{
private:
  Tbase* vec;
  int nelementos;
  int reservados;
public:
  APO();
  APO(int tam);
  APO(const APO<Tbase>& a);
  ~APO();
  APO<Tbase>& operator=(const APO<Tbase>& a);
  const Tbase& minimo() const;
  void borrar_minimo();
  void insertar(const Tbase& e);
  void clear();
  int size() const;
  bool empty() const;
private:
  void expandir(int nelem);
};

//Función auxiliar genérica, pero externa a la clase
template <class Tbase>
void intercambiar (Tbase& a, Tbase& b);

#endif /* APO_hpp */
