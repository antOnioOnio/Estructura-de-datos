#include "APO.hpp"
#include "APO.cpp"

template class APO<int>;
