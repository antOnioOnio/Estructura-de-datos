#define CUAL_COMPILA 1
#if CUAL_COMPILA==1
#include <Pila_max_VD.h>
#else
#include <Pila_max_cola.h>
#endif